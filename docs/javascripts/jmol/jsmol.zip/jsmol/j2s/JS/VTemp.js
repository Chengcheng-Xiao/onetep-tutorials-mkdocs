Clazz.declarePackage ("JS");
Clazz.load (["JU.BS", "$.V3"], "JS.VTemp", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.vTemp = null;
this.vA = null;
this.vB = null;
this.vTemp1 = null;
this.vTemp2 = null;
this.vNorm2 = null;
this.vNorm3 = null;
this.vNorm4 = null;
this.bsTemp = null;
Clazz.instantialize (this, arguments);
}, JS, "VTemp");
Clazz.prepareFields (c$, function () {
this.vTemp =  new JU.V3 ();
this.vA =  new JU.V3 ();
this.vB =  new JU.V3 ();
this.vTemp1 =  new JU.V3 ();
this.vTemp2 =  new JU.V3 ();
this.vNorm2 =  new JU.V3 ();
this.vNorm3 =  new JU.V3 ();
this.vNorm4 =  new JU.V3 ();
this.bsTemp =  new JU.BS ();
});
});
