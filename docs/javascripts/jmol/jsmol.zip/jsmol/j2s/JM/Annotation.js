Clazz.declarePackage ("JM");
Clazz.load (["JM.ProteinStructure"], "JM.Annotation", null, function () {
c$ = Clazz.declareType (JM, "Annotation", JM.ProteinStructure);
});
